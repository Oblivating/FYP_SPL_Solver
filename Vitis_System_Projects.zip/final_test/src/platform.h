/******************************************************************************
* Copyright (c) 2021 Xilinx, Inc.  All rights reserved.
* SPDX-License-Identifier: MIT
 ******************************************************************************/

#ifndef __PLATFORM_H_
#define __PLATFORM_H_

#include "platform_config.h"

void init_platform();
void cleanup_platform();

#endif
