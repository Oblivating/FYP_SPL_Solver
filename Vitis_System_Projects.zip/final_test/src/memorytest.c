/******************************************************************************
* Copyright (c) 2021 Xilinx, Inc.  All rights reserved.
* SPDX-License-Identifier: MIT
 ******************************************************************************/

#include <stdio.h>
#include "xparameters.h"
#include "xil_types.h"
#include "xstatus.h"
#include "xil_testmem.h"

#include "platform.h"
#include "memory_config.h"
#include "xil_printf.h"

#include "xil_io.h"
#define INSTR_BASE XPAR_PL_PS_AXI_0_S00_AXI_BASEADDR
#define SREG0_OFFSET 0
#define SREG1_OFFSET 4
#define SREG2_OFFSET 8
#define SREG3_OFFSET 12
#define SREG4_OFFSET 16
#define SREG5_OFFSET 20
#define SREG6_OFFSET 24
#define SREG7_OFFSET 28
#define SREG8_OFFSET 32
#define SREG9_OFFSET 36

#define INSTR_WriteReg(BaseAddress, RegOffset, Data) Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define INSTR_ReadReg(BaseAddress, RegOffset) Xil_In32((BaseAddress) + (RegOffset))

/*
 * memory_test.c: Test memory ranges present in the Hardware Design.
 *
 * This application runs with D-Caches disabled. As a result cacheline requests
 * will not be generated.
 *
 * For MicroBlaze/PowerPC, the BSP doesn't enable caches and this application
 * enables only I-Caches. For ARM, the BSP enables caches by default, so this
 * application disables D-Caches before running memory tests.
 */

void putnum(unsigned int num);

void test_memory_range(struct memory_range_s *range) {
    XStatus status;

    /* This application uses print statements instead of xil_printf/printf
     * to reduce the text size.
     *
     * The default linker script generated for this application does not have
     * heap memory allocated. This implies that this program cannot use any
     * routines that allocate memory on heap (printf is one such function).
     * If you'd like to add such functions, then please generate a linker script
     * that does allocate sufficient heap memory.
     */

    print("Testing memory region: "); print(range->name);  print("\n\r");
    print("    Memory Controller: "); print(range->ip);  print("\n\r");
    #if defined(__MICROBLAZE__) && !defined(__arch64__)
        #if (XPAR_MICROBLAZE_ADDR_SIZE > 32)
            print("         Base Address: 0x"); putnum((range->base & UPPER_4BYTES_MASK) >> 32); putnum(range->base & LOWER_4BYTES_MASK);print("\n\r");
        #else
            print("         Base Address: 0x"); putnum(range->base); print("\n\r");
        #endif
        print("                 Size: 0x"); putnum(range->size); print (" bytes \n\r");
    #else
        xil_printf("         Base Address: 0x%lx \n\r",range->base);
        xil_printf("                 Size: 0x%lx bytes \n\r",range->size);
    #endif

#if defined(__MICROBLAZE__) && !defined(__arch64__) && (XPAR_MICROBLAZE_ADDR_SIZE > 32)
    status = Xil_TestMem32((range->base & LOWER_4BYTES_MASK), ((range->base & UPPER_4BYTES_MASK) >> 32), 1024, 0xAAAA5555, XIL_TESTMEM_ALLMEMTESTS);
    print("          32-bit test: "); print(status == XST_SUCCESS? "PASSED!":"FAILED!"); print("\n\r");

    status = Xil_TestMem16((range->base & LOWER_4BYTES_MASK), ((range->base & UPPER_4BYTES_MASK) >> 32), 2048, 0xAA55, XIL_TESTMEM_ALLMEMTESTS);
    print("          16-bit test: "); print(status == XST_SUCCESS? "PASSED!":"FAILED!"); print("\n\r");

    status = Xil_TestMem8((range->base & LOWER_4BYTES_MASK), ((range->base & UPPER_4BYTES_MASK) >> 32), 4096, 0xA5, XIL_TESTMEM_ALLMEMTESTS);
    print("           8-bit test: "); print(status == XST_SUCCESS? "PASSED!":"FAILED!"); print("\n\r");
#else
    status = Xil_TestMem32((u32*)range->base, 1024, 0xAAAA5555, XIL_TESTMEM_ALLMEMTESTS);
    print("          32-bit test: "); print(status == XST_SUCCESS? "PASSED!":"FAILED!"); print("\n\r");

    status = Xil_TestMem16((u16*)range->base, 2048, 0xAA55, XIL_TESTMEM_ALLMEMTESTS);
    print("          16-bit test: "); print(status == XST_SUCCESS? "PASSED!":"FAILED!"); print("\n\r");

    status = Xil_TestMem8((u8*)range->base, 4096, 0xA5, XIL_TESTMEM_ALLMEMTESTS);
    print("           8-bit test: "); print(status == XST_SUCCESS? "PASSED!":"FAILED!"); print("\n\r");
#endif

}

int main()
{

	init_platform();

	// Phase
	INSTR_WriteReg(INSTR_BASE, SREG0_OFFSET, 0x00000000);
	// Period
	INSTR_WriteReg(INSTR_BASE, SREG1_OFFSET, 0x00000000);
	// Duty
	INSTR_WriteReg(INSTR_BASE, SREG2_OFFSET, 0x00000000);

	// 0 for stop; 1 for 200kHz; 2 for 400kHz
	int phase[3] = {0x00000000, 0x00000320, 0x000000C8};
	int period[3] = {0x00000000, 0x00001388, 0x000009C4};
	int duty[3] = {0x00000000, 0x000009C4, 0x000004E2};

	int i = 0;
	while(1) {

		printf("Choose PWM Config (0 for reset): ");
		scanf("%1d", &i);

		// Phase
		INSTR_WriteReg(INSTR_BASE, SREG0_OFFSET, phase[i]);
		// Period
		INSTR_WriteReg(INSTR_BASE, SREG1_OFFSET, period[i]);
		// Duty
		INSTR_WriteReg(INSTR_BASE, SREG2_OFFSET, duty[i]);

		printf("PWM set successful\n");

	}

	cleanup_platform();
	return 0;
}
